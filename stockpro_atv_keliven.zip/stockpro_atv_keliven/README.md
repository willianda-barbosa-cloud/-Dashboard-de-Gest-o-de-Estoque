# StockPro - Dashboard de Estoque

Dashboard de gestão de estoque feito com React + Vite.

## Como rodar

```bash
npm install
npm run dev
```

## Estrutura

- `src/components/Header.jsx` - cabeçalho com o nome do sistema
- `src/components/StatCard.jsx` - card de indicador (reutilizado 3x via props)
- `src/components/ProductTable.jsx` - tabela de produtos com `.map()`
- `src/components/StatusBadge.jsx` - badge de status (estoque baixo em vermelho)
- `src/components/Sidebar.jsx` - menu lateral
- `src/components/CategoryChart.jsx` - gráfico de produtos por categoria
- `src/data/products.js` - array de produtos
