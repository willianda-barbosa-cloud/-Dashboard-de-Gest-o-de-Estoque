import Header from './components/Header'
import Sidebar from './components/Sidebar'
import StatCard from './components/StatCard'
import CategoryChart from './components/CategoryChart'
import ProductTable from './components/ProductTable'
import { products, LIMITE_ESTOQUE_BAIXO } from './data/products'

function App() {
  const total = products.length
  const baixo = products.filter((p) => p.quantidade <= LIMITE_ESTOQUE_BAIXO).length
  const emEstoque = total - baixo

  // Conta quantos produtos existem em cada categoria
  const porCategoria = products.reduce((acc, p) => {
    acc[p.categoria] = (acc[p.categoria] || 0) + 1
    return acc
  }, {})
  const dadosGrafico = Object.entries(porCategoria).map(([categoria, qtd]) => ({
    categoria,
    total: qtd,
  }))

  // Os 3 indicadores usam o mesmo componente StatCard
  const indicadores = [
    { id: 1, titulo: 'Total de Produtos', valor: total, cor: 'azul', icone: '📦' },
    { id: 2, titulo: 'Produtos em Estoque', valor: emEstoque, cor: 'verde', icone: '✅' },
    { id: 3, titulo: 'Estoque Baixo', valor: baixo, cor: 'vermelho', icone: '⚠️' },
  ]

  return (
    <div className="layout">
      <Header nome="StockPro" subtitulo="Estoque" />
      <Sidebar ativo="dashboard" />

      <main className="conteudo">
        <div className="conteudo__titulo">
          <h2>📈 Dashboard</h2>
          <p>Visão geral do estoque da empresa.</p>
        </div>

        <div className="stats">
          {indicadores.map((item) => (
            <StatCard
              key={item.id}
              titulo={item.titulo}
              valor={item.valor}
              cor={item.cor}
              icone={item.icone}
            />
          ))}
        </div>

        <div className="paineis">
          <CategoryChart dados={dadosGrafico} />
          <ProductTable produtos={products} />
        </div>
      </main>
    </div>
  )
}

export default App
