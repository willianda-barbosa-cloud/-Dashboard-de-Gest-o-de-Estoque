function CategoryChart({ dados }) {
  const maior = Math.max(...dados.map((d) => d.total))

  return (
    <section className="panel">
      <h2 className="panel__titulo">📊 Quantidade de produtos por categoria</h2>
      <div className="chart">
        {dados.map((d) => (
          <div className="chart__coluna" key={d.categoria}>
            <span className="chart__valor">{d.total}</span>
            <div className="chart__barra" style={{ height: `${(d.total / maior) * 100}%` }} />
            <span className="chart__rotulo">{d.categoria}</span>
          </div>
        ))}
      </div>
    </section>
  )
}

export default CategoryChart