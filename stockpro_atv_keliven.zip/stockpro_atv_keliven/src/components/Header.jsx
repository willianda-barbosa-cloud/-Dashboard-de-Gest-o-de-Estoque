function Header({ nome, subtitulo }) {
  return (
    <header className="header">
      <div className="header__logo" aria-hidden="true">
        📦
      </div>
      <div>
        <h1 className="header__nome">{nome}</h1>
        <span className="header__subtitulo">{subtitulo}</span>
      </div>
    </header>
  )
}

export default Header