import StatusBadge from './StatusBadge'
import { LIMITE_ESTOQUE_BAIXO } from '../data/products'

const emojiCategoria = {
  'Eletrônicos': '💻',
  'Escritório': '🪑',
  'Limpeza': '🧴',
  'Alimentos': '🍚',
}

function ProductTable({ produtos }) {
  return (
    <section className="panel">
      <h2 className="panel__titulo">📋 Produtos em estoque</h2>
      <div className="table-wrapper">
        <table className="table">
          <thead>
            <tr>
              <th>Produto</th>
              <th>Categoria</th>
              <th>Quantidade</th>
              <th>Status</th>
            </tr>
          </thead>
          <tbody>
            {produtos.map((produto) => {
              const baixo = produto.quantidade <= LIMITE_ESTOQUE_BAIXO
              return (
                <tr key={produto.id} className={baixo ? 'table__linha--baixo' : ''}>
                  <td className="table__nome">{produto.nome}</td>
                  <td>
                    {emojiCategoria[produto.categoria]} {produto.categoria}
                  </td>
                  <td className={baixo ? 'table__qtd--baixo' : ''}>{produto.quantidade}</td>
                  <td>
                    <StatusBadge baixo={baixo} />
                  </td>
                </tr>
              )
            })}
          </tbody>
        </table>
      </div>
    </section>
  )
}

export default ProductTable