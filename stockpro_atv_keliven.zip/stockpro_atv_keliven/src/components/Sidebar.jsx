const itens = [
  { id: 'dashboard', rotulo: '🏠 Dashboard' },
  { id: 'produtos', rotulo: '📦 Produtos' },
  { id: 'movimentacoes', rotulo: '🔄 Movimentações' },
]

function Sidebar({ ativo }) {
  return (
    <nav className="sidebar" aria-label="Navegação principal">
      <ul>
        {itens.map((item) => (
          <li key={item.id}>
            <a
              href={`#${item.id}`}
              className={`sidebar__link ${item.id === ativo ? 'sidebar__link--ativo' : ''}`}
              aria-current={item.id === ativo ? 'page' : undefined}
            >
              {item.rotulo}
            </a>
          </li>
        ))}
      </ul>
    </nav>
  )
}

export default Sidebar
