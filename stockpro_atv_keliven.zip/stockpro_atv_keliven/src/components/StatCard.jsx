// Card reutilizável: recebe tudo por props
// cor: 'azul' | 'verde' | 'vermelho'
function StatCard({ titulo, valor, cor, icone }) {
  return (
    <div className="stat-card">
      <div className={`stat-card__icone stat-card__icone--${cor}`}>{icone}</div>
      <div>
        <p className="stat-card__titulo">{titulo}</p>
        <p className="stat-card__valor">{valor}</p>
      </div>
    </div>
  )
}

export default StatCard
