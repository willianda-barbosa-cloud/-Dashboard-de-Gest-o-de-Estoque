// Quantidade igual ou abaixo deste valor é considerada "estoque baixo"
export const LIMITE_ESTOQUE_BAIXO = 3

export const products = [
  { id: 1, nome: 'Notebook', categoria: 'Eletrônicos', quantidade: 5 },
  { id: 2, nome: 'Mouse', categoria: 'Eletrônicos', quantidade: 10 },
  { id: 3, nome: 'Monitor', categoria: 'Eletrônicos', quantidade: 4 },
  { id: 4, nome: 'Teclado', categoria: 'Eletrônicos', quantidade: 2 },
  { id: 5, nome: 'Webcam', categoria: 'Eletrônicos', quantidade: 8 },
  { id: 6, nome: 'Cadeira', categoria: 'Escritório', quantidade: 3 },
  { id: 7, nome: 'Papel A4', categoria: 'Escritório', quantidade: 50 },
  { id: 8, nome: 'Caneta', categoria: 'Escritório', quantidade: 25 },
  { id: 9, nome: 'Detergente', categoria: 'Limpeza', quantidade: 2 },
  { id: 10, nome: 'Desinfetante', categoria: 'Limpeza', quantidade: 12 },
  { id: 11, nome: 'Arroz', categoria: 'Alimentos', quantidade: 1 },
  { id: 12, nome: 'Café', categoria: 'Alimentos', quantidade: 6 },
]
